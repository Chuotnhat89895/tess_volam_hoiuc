/*****************************************************************************************
//	������Core server �ӿڷ���
//	Copyright : Kingsoft 2002
//	Author	:   Wooy (Wu yue)
//	CreateTime:	2002-12-20
------------------------------------------------------------------------------------------
*****************************************************************************************/
#include "KCore.h"
#include "CoreServerShell.h"
#include "KThread.h"
#include "KPlayer.h"
#include "KItemList.h"
#include "KSubWorldSet.h"
#include "KProtocolProcess.h"
#include "KNewProtocolProcess.h"
#include "KPlayerSet.h"
#include "KLadder.h"

#ifdef _STANDALONE
#include "KLadder.cpp"
#endif

//#include "KNetServer.h"
//#include "../MultiServer/Heaven/Interface/iServer.h"
#ifdef _STANDALONE
#include "IClient.h"
#else
#include "../../lib/S3DBInterface.h"
#include "../../Headers/IClient.h"
#include "../../../Headers/IClient.h"
#include "../../../Headers/KGmProtocol.h"
#endif

#include "LuaFuns.h"
#include "KSortScript.h"
#include "KSubWorld.h"


#include "malloc.h"

class CoreServerShell : public iCoreServerShell
{



public:
	int  GetLoopRate();
	void GetGuid(int nIndex, void* pGuid);
	DWORD GetExchangeMap(int nIndex);
	bool IsPlayerLoginTimeOut(int nIndex);
	void RemovePlayerLoginTimeOut(int nIndex);
	bool IsPlayerExchangingServer(int nIndex);
	void ProcessClientMessage(int nIndex, const char* pChar, int nSize);
	void ProcessNewClientMessage(IClient*, DWORD, DWORD, int nIndex, const char* pChar, int nSize);
	void SendNetMsgToTransfer(IClient* pClient);
	void SendNetMsgToChat(IClient* pClient);
	void SendNetMsgToTong(IClient* pClient);
	void ProcessBroadcastMessage(const char* pChar, int nSize);
	void ProcessExecuteMessage(const char* pChar, int nSize);
	void ClientDisconnect(int nIndex);
	void RemoveQuitingPlayer(int nIndex);
	void* SavePlayerDataAtOnce(int nIndex);
	bool IsCharacterQuiting(int nIndex);
	// UY THAC
	int  IsCharacterLiXian(int nIndex);
	int  IsCheckLiXian(int nIndex);
	void SetCharacterLiXian(int nIndex,int i);
	// END
	//void SetAutoTroLai(int nIndex, BOOL bCheck); // AUTO QUAY LAI

	bool CheckProtocolSize(const char* pChar, int nSize);
	bool PlayerDbLoading(int nPlayerIndex, int bSyncEnd, int& nStep, unsigned int& nParam);

	void ExSpcritStarPlayer(int nPlayerIndex);

	void ExSpcritStopPlayer(int nPlayerIndex);

	void KickAcountAndBlock(int nPlayerIndex,const char* szNameCpuIp);

	int  AttachPlayer(const unsigned long lnID, GUID* pGuid);
	void GetPlayerIndexByGuid(GUID* pGuid, int* pnIndex, int* plnID);
	void AddPlayerToWorld(int nIndex);
	void* PreparePlayerForExchange(int nIndex);
	void PreparePlayerForLoginFailed(int nIndex);
	void RemovePlayerForExchange(int nIndex);
	void RecoverPlayerExchange(int nIndex);
	int  AddCharacter(int nExtPoint, int nChangeExtPoint, void* pBuffer, GUID* pGuid);
	int	 AddTempTaskValue(int nIndex, const char* pData);
	//����Ϸ���Ͳ���
	int	 OperationRequest(unsigned int uOper, unsigned int uParam, int nParam);
	//��ȡ����״��
	int	 GetConnectInfo(KCoreConnectInfo* pInfo);
	//BOOL ValidPingTime(int nIndex);
	//����Ϸ�����ȡ����
	int	 GetGameData(unsigned int uDataId, unsigned int uParam, int nParam);
	//�ճ����core���Ҫ���������򷵻�0�����򷵻ط�0ֵ
	int  Breathe();

	//�ͷŽӿڶ���
	void Release();
	void SetSaveStatus(int nIndex, UINT uStatus);
	UINT GetSaveStatus(int nIndex);

	BOOL GroupChat(IClient* pClient, DWORD FromIP, unsigned long FromRelayID, DWORD channid, BYTE tgtcls, DWORD tgtid, const void* pData, size_t size);
	void SetLadder(void* pData, size_t uSize);
	BOOL PayForSpeech(int nIndex, int nType);
	BOOL PayForSpeech2(int nIndex, int nType, int nChanelId);
	BOOL CheckCastChat(int nIndex, int nType);
private:
	int	 OnLunch(LPVOID pServer);
	int	 OnShutdown();
};

static CoreServerShell	g_CoreServerShell;

CORE_API void g_InitCore();

#ifndef _STANDALONE
extern "C" __declspec(dllexport)
#endif
iCoreServerShell* CoreGetServerShell()
{
	g_InitCore();
	return &g_CoreServerShell;
}

void CoreServerShell::Release()
{
	g_ReleaseCore();
}

int CoreServerShell::GetLoopRate()
{
	return g_SubWorldSet.m_nLoopRate;
}

	//��ȡ����״��
int	 CoreServerShell::GetConnectInfo(KCoreConnectInfo* pInfo)
{
	if (pInfo)
		pInfo->nNumPlayer = PlayerSet.GetPlayerNumber();
	return 1;
}


int CoreServerShell::AddCharacter(int nExtPoint, int nChangeExtPoint, void* pBuffer, GUID* pGuid)
{
	int nIdx = 0;
	const TRoleData* pData = (const TRoleData*)pBuffer;

	if (pData && pData->BaseInfo.szName[0])
	{
		nIdx = PlayerSet.Add((char*)pData->BaseInfo.szName, pGuid);
		if (nIdx <= 0 || nIdx >= MAX_PLAYER)
			return 0;
		strcpy(Player[nIdx].m_AccoutName, pData->BaseInfo.caccname);
		strcpy(Player[nIdx].m_PlayerName, pData->BaseInfo.szName);
		DWORD	dwLen = pData->dwDataLen;
//		_ASSERT(dwLen < 64 * 1024);
		ZeroMemory(Player[nIdx].m_SaveBuffer, sizeof(Player[nIdx].m_SaveBuffer));
		memcpy(Player[nIdx].m_SaveBuffer, pBuffer, dwLen);

		Player[nIdx].m_pStatusLoadPlayerInfo = Player[nIdx].m_SaveBuffer;
		// ��չ�㣬���ڻ
		Player[nIdx].SetExtPoint(nExtPoint, nChangeExtPoint);
	//	printf("IDX: %d Ext: %d Change: %d \n",nIdx,nExtPoint,nChangeExtPoint);
		return nIdx;
	}
	return 0;
}

void CoreServerShell::ExSpcritStarPlayer(int nPlayerIndex)
{

if (nPlayerIndex <= 0 || nPlayerIndex >= MAX_PLAYER)
return;

Player[nPlayerIndex].ExecuteScript("\\script\\admin\\dangnhap.lua","main",0);

}



void CoreServerShell::ExSpcritStopPlayer(int nPlayerIndex)
{

if (nPlayerIndex <= 0 || nPlayerIndex >= MAX_PLAYER)
return;

Player[nPlayerIndex].ExecuteScript("\\script\\admin\\dangthoat.lua","main",0);

}


void CoreServerShell::KickAcountAndBlock(int nPlayerIndex,const char* szNameCpuIp)
{

if (nPlayerIndex <= 0 || nPlayerIndex >= MAX_PLAYER)
return;





for (int i=1;i<MAX_PLAYER;i++)
{


if (i == nPlayerIndex || Player[i].m_nNetConnectIdx == -1 || Player[i].m_bExchangeServer || Player[i].m_bIsQuiting)
continue;

if (!Player[i].m_PlayerName || !Player[nPlayerIndex].m_PlayerName || !Player[i].m_PlayerName[0] || !Player[nPlayerIndex].m_PlayerName[0])
continue;

if (strcmp(Player[i].m_PlayerName,Player[nPlayerIndex].m_PlayerName) != 0 )
continue;

printf("Kick by Name luu %d %s !!!!!!!!!\n",nPlayerIndex,Player[nPlayerIndex].m_PlayerName);
g_pServer->ShutdownClient(Player[i].m_nNetConnectIdx);

}



memcpy(Player[nPlayerIndex].m_szCPUIPName, szNameCpuIp,sizeof(Player[nPlayerIndex].m_szCPUIPName));
Player[nPlayerIndex].m_szCPUIPName[sizeof(Player[nPlayerIndex].m_szCPUIPName) - 1] = 0;


}



bool CoreServerShell::PlayerDbLoading(int nPlayerIndex, int bSyncEnd, int& nStep, unsigned int& nParam)
{
	TRoleData* pData = (TRoleData *)Player[nPlayerIndex].m_pStatusLoadPlayerInfo;
	
	if (bSyncEnd)
	{
		Player[nPlayerIndex].m_pStatusLoadPlayerInfo = NULL;
		nStep = 0;
		nParam = 0;

		return true;
	}
	else if (pData)	
	{
//		if (0 == Player[nPlayerIndex].LoadDBPlayerInfo((BYTE *)pData, nStep, nParam))
//		{
//			// ����ҵĵ���״̬����Ϊδ���룬�ȴ�ʱ���Զ����
//			Player[nPlayerIndex].m_nNetConnectIdx = -1;
//			Player[nPlayerIndex].m_dwLoginTime = -1;
//			return false;
//		}
//		else
//			return true;
		
		return Player[nPlayerIndex].LoadDBPlayerInfo((BYTE *)pData, nStep, nParam);
	}
	return false;
}

void CoreServerShell::AddPlayerToWorld(int nIndex)
{
	Player[nIndex].LaunchPlayer();
}

void CoreServerShell::ProcessClientMessage(int nIndex, const char* pChar, int nSize)
{
	PlayerSet.ProcessClientMessage(nIndex, pChar, nSize);
}

void CoreServerShell::ProcessNewClientMessage(IClient* pTransfer,
									   DWORD dwFromIP, DWORD dwFromRelayID,
									   int nPlayerIndex,
									   const char* pChar, int nSize)
{
	g_NewProtocolProcess.ProcessNetMsg(pTransfer, dwFromIP, dwFromRelayID,
										nPlayerIndex, (BYTE*)pChar, nSize);

}

void CoreServerShell::SendNetMsgToTransfer(IClient* pClient)
{
	g_NewProtocolProcess.SendNetMsgToTransfer(pClient);
}

void CoreServerShell::SendNetMsgToChat(IClient* pClient)
{
	g_NewProtocolProcess.SendNetMsgToChat(pClient);
}

void CoreServerShell::SendNetMsgToTong(IClient* pClient)
{
	g_NewProtocolProcess.SendNetMsgToTong(pClient);
}

void CoreServerShell::ProcessBroadcastMessage(const char* pChar, int nSize)
{
	g_NewProtocolProcess.BroadcastLocalServer(pChar, nSize);
}

void CoreServerShell::ProcessExecuteMessage(const char* pChar, int nSize)
{
	g_NewProtocolProcess.ExecuteLocalServer(pChar, nSize);
}

void CoreServerShell::ClientDisconnect(int nIndex)
{
//	PlayerSet.Remove(nClient);
	PlayerSet.PrepareRemove(nIndex);
}

void CoreServerShell::RemoveQuitingPlayer(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;

	if (Player[nIndex].IsWaitingRemove())
	{
		PlayerSet.RemoveQuiting(nIndex);
	}
}
//--------------------------------------------------------------------------
//	���ܣ�����Ϸ�����ȡ����
//	������unsigned int uDataId --> ��ʾ��ȡ��Ϸ���ݵ�������������������ֵΪ÷������
//							GAMEDATA_INDEX��ȡֵ֮һ��
//		  unsigned int uParam  --> ����uDataId��ȡֵ�������
//		  int nParam --> ����uDataId��ȡֵ�������
//	���أ�����uDataId��ȡֵ���������
//--------------------------------------------------------------------------
int	CoreServerShell::GetGameData(unsigned int uDataId, unsigned int uParam, int nParam)
{
	int nRet = 0;
	switch(uDataId)
	{
	case SGDI_CHARACTER_ACCOUNT:
		if (uParam)
		{
			nRet = PlayerSet.GetPlayerAccount(nParam, (char *)uParam);
			if (nRet == FALSE)
				((char *)uParam)[0] = 0;
		}
		break;
	case SGDI_CHARACTER_NAME:
		if (uParam)
		{
			nRet = PlayerSet.GetPlayerName(nParam, (char*)uParam);
			if (nRet == FALSE)
				((char *)uParam)[0] = 0;
		}
		break;
	case SGDI_CHARACTER_EXTPOINTCHANGED:
		if (uParam)
		{
			if (uParam >= MAX_PLAYER)
			{
				nRet = 0;
				break;
			}
			nRet = Player[uParam].GetExtPointChanged();
		}
		break;
	case SGDI_CHARACTER_EXTPOINT:
		if (uParam)
		{
			if (uParam >= MAX_PLAYER)
			{
				nRet = 0;
				break;
			}
			nRet = Player[uParam].GetExtPoint();
		}
		break;
	case SGDI_LOADEDMAP_ID:
		if (uParam)
		{
			int i;
			int nMax = nParam;
			if(nMax < MAX_SUBWORLD) nMax = MAX_SUBWORLD;
			for (i = 0; i < nMax; i++)
			{
				if (SubWorld[i].m_SubWorldID != -1)
				{
					((char *)uParam)[i] = (char)SubWorld[i].m_SubWorldID;
				}
				else
				{
					nRet = i;
					break;
				}
			}
		}
		break;
	case SGDI_CHARACTER_ID:
		if (uParam)
		{
			if (uParam >= MAX_PLAYER)
			{
				nRet = 0;
				break;
			}

			nRet = Player[uParam].m_dwID;
			break;
		}
		break;
	case SGDI_CHARACTER_NETID:
		if (uParam)
		{
			if (uParam >= MAX_PLAYER)
			{
				nRet = -1;
				break;
			}
			nRet = Player[uParam].m_nNetConnectIdx;
		}
		break;

	// �����Ὠ�����������������Ƿ����
	// uParam : struct STONG_SERVER_TO_CORE_APPLY_CREATE point
	// return : �����Ƿ����
	case SGDI_TONG_APPLY_CREATE:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_APPLY_CREATE	*pApply = (STONG_SERVER_TO_CORE_APPLY_CREATE*)uParam;

			int		nPlayerIdx;
			int		nCamp;
			char	szTongName[defTONG_NAME_MAX_LENGTH + 2];

			szTongName[sizeof(szTongName) - 1] = 0;
			memcpy(szTongName, pApply->m_szTongName, sizeof(szTongName));
			nPlayerIdx = pApply->m_nPlayerIdx;
			nCamp = pApply->m_nCamp;

			if (nPlayerIdx <= 0 || nPlayerIdx >= MAX_PLAYER)
			{
				nRet = FALSE;
				break;
			}

			
			nRet = Player[nPlayerIdx].m_cTong.ApplyCreateTong(nCamp, szTongName);
		}
		break;
	case SGDI_TONG_APPLY_CHANGE:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_APPLY_CHANGE	*pApply = (STONG_SERVER_TO_CORE_APPLY_CHANGE*)uParam;

			int		nPlayerIdx;
			int		nCamp;
			char	szTongName[defTONG_NAME_MAX_LENGTH + 2];

			szTongName[sizeof(szTongName) - 1] = 0;
			memcpy(szTongName, pApply->m_szTongName, sizeof(szTongName));
			nPlayerIdx = pApply->m_nPlayerIdx;
			nCamp = pApply->m_nCamp;

			if (nPlayerIdx <= 0 || nPlayerIdx >= MAX_PLAYER)
			{
				nRet = FALSE;
				break;
			}

			
			nRet = Player[nPlayerIdx].m_cTong.ApplyChangeTongCamp(nCamp, szTongName);
		}
		break;
	// ���������
	// uParam : struct STONG_SERVER_TO_CORE_APPLY_ADD point
	case SGDI_TONG_APPLY_ADD:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_APPLY_ADD	*pAdd = (STONG_SERVER_TO_CORE_APPLY_ADD*)uParam;
			if (pAdd->m_nPlayerIdx <= 0 || pAdd->m_nPlayerIdx >= MAX_PLAYER)
				break;
			Player[pAdd->m_nPlayerIdx].m_cTong.TransferAddApply(pAdd->m_dwNpcID);
		}
		break;

	// �жϼ����������Ƿ����
	// uParam : ����� char point �����ڽ��հ������
	// nParam : struct STONG_SERVER_TO_CORE_CHECK_ADD_CONDITION point
	case SGDI_TONG_CHECK_ADD_CONDITION:
		{
			
			STONG_SERVER_TO_CORE_CHECK_ADD_CONDITION	*pAdd;
			pAdd = (STONG_SERVER_TO_CORE_CHECK_ADD_CONDITION*)nParam;
			if (pAdd->m_nSelfIdx <= 0 || pAdd->m_nSelfIdx >= MAX_PLAYER)
				break;
			if (pAdd->m_nTargetIdx <= 0 || pAdd->m_nTargetIdx >= MAX_PLAYER || g_FileName2Id(Npc[Player[pAdd->m_nTargetIdx].m_nIndex].Name) != pAdd->m_dwNameID)
				break;
			Player[pAdd->m_nTargetIdx].m_cTong.ApplyAddMember(pAdd->m_nSelfIdx);
			
		}
		break;

	// ��ð����Ϣ
	// uParam : ����� STONG_SERVER_TO_CORE_GET_INFO point
	case SGDI_TONG_GET_INFO:
		{
			STONG_SERVER_TO_CORE_GET_INFO	*pInfo = (STONG_SERVER_TO_CORE_GET_INFO*)uParam;
			switch (pInfo->m_nInfoID)
			{
			case enumTONG_APPLY_INFO_ID_SELF:
				{
					if (pInfo->m_nSelfIdx <= 0 || pInfo->m_nSelfIdx >= MAX_PLAYER)
						break;
					Player[pInfo->m_nSelfIdx].m_cTong.SendSelfInfo();
				}
				break;
			case enumTONG_APPLY_INFO_ID_MASTER:
				break;
			case enumTONG_APPLY_INFO_ID_DIRECTOR:
				break;
			case enumTONG_APPLY_INFO_ID_MANAGER:
				{
					
					if (pInfo->m_nSelfIdx <= 0 || pInfo->m_nSelfIdx >= MAX_PLAYER)
						break;
					if (Player[pInfo->m_nSelfIdx].m_cTong.CanGetManagerInfo((DWORD)pInfo->m_nParam1))
						Player[pInfo->m_nSelfIdx].m_cTong.LoadTongInfo(pInfo->m_nInfoID,0,Player[pInfo->m_nSelfIdx].m_cTong.GetTongNameID());
				}
				break;
			case enumTONG_APPLY_INFO_ID_MEMBER:
				{
					
					if (pInfo->m_nSelfIdx <= 0 || pInfo->m_nSelfIdx >= MAX_PLAYER)
						break;
					if (Player[pInfo->m_nSelfIdx].m_cTong.CanGetMemberInfo((DWORD)pInfo->m_nParam1))
						Player[pInfo->m_nSelfIdx].m_cTong.LoadTongInfo(pInfo->m_nInfoID,0,Player[pInfo->m_nSelfIdx].m_cTong.GetTongNameID());
				}
				break;
			case enumTONG_APPLY_INFO_ID_ONE:
				break;

			case enumTONG_APPLY_INFO_ID_TONG_HEAD:
				{
					
					if (pInfo->m_nSelfIdx <= 0 || pInfo->m_nSelfIdx >= MAX_PLAYER)
						break;
					
					if (Npc[Player[pInfo->m_nSelfIdx].m_nIndex].m_dwID == (DWORD)pInfo->m_nParam1)
					{
						Player[pInfo->m_nSelfIdx].m_cTong.LoadTongInfo(pInfo->m_nInfoID,0,Player[pInfo->m_nSelfIdx].m_cTong.GetTongNameID());
					}
					else
					{

					int nPlayer = Player[pInfo->m_nSelfIdx].FindAroundPlayer((DWORD)pInfo->m_nParam1);

					

					if (nPlayer == -1)
						break;
	

					    Player[pInfo->m_nSelfIdx].m_cTong.LoadTongInfo(pInfo->m_nInfoID,nPlayer,Player[nPlayer].m_cTong.GetTongNameID());

					}
					
				}
				break;
			}
		}
		break;

	// �ж��Ƿ�������Ȩ��
	// uParam : ����� TONG_APPLY_INSTATE_COMMAND point
	// nParam : PlayerIndex
	case SGDI_TONG_INSTATE_POWER:
		if (uParam)
		{
			
			TONG_APPLY_INSTATE_COMMAND	*pApply = (TONG_APPLY_INSTATE_COMMAND*)uParam;
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;
			if (Player[nParam].m_nIndex <= 0)
				break;
			 Player[nParam].m_cTong.InstatePower(pApply);
		}
		break;

	// ��������������ݱ仯
	// uParam : ����� STONG_SERVER_TO_CORE_BE_INSTATED point
	case SGDI_TONG_BE_INSTATED:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_BE_INSTATED	*pInstated = (STONG_SERVER_TO_CORE_BE_INSTATED*)uParam;
			if (pInstated->m_nPlayerIdx <= 0 || pInstated->m_nPlayerIdx >= MAX_PLAYER)
				break;
			if (Player[pInstated->m_nPlayerIdx].m_nIndex <= 0)
				break;
			Player[pInstated->m_nPlayerIdx].m_cTong.BeInstated(pInstated);
		}
		break;

	// �ж��Ƿ�������Ȩ��
	// uParam : ����� TONG_APPLY_KICK_COMMAND point
	// nParam : PlayerIndex
	case SGDI_TONG_KICK_POWER:
		if (uParam)
		{
		
			TONG_APPLY_KICK_COMMAND	*pKick = (TONG_APPLY_KICK_COMMAND*)uParam;
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;
			if (Player[nParam].m_nIndex <= 0)
				break;
			 Player[nParam].m_cTong.KickPower(pKick);
		}
		break;

	// ���߳����
	// uParam : ����� STONG_SERVER_TO_CORE_BE_KICKED point
	case SGDI_TONG_BE_KICKED:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_BE_KICKED	*pKicked = (STONG_SERVER_TO_CORE_BE_KICKED*)uParam;
			if (pKicked->m_nPlayerIdx <= 0 || pKicked->m_nPlayerIdx >= MAX_PLAYER)
				break;
			if (Player[pKicked->m_nPlayerIdx].m_nIndex <= 0)
				break;
			Player[pKicked->m_nPlayerIdx].m_cTong.BeKicked(pKicked);
		}
		break;

	// �뿪���
	// uParam : ����� TONG_APPLY_LEAVE_COMMAND point
	// nParam : PlayerIndex
	case SGDI_TONG_LEAVE_POWER:
		if (uParam)
		{
		
			TONG_APPLY_LEAVE_COMMAND	*pLeave = (TONG_APPLY_LEAVE_COMMAND*)uParam;
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;
			if (Player[nParam].m_nIndex <= 0)
				break;
			    Player[nParam].m_cTong.LeavePower(pLeave);
		}
		break;

	// �뿪���
	// uParam : ����� STONG_SERVER_TO_CORE_LEAVE point
	case SGDI_TONG_LEAVE:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_LEAVE	*pLeave = (STONG_SERVER_TO_CORE_LEAVE*)uParam;
			if (pLeave->m_nPlayerIdx <= 0 || pLeave->m_nPlayerIdx >= MAX_PLAYER)
				break;
			if (Player[pLeave->m_nPlayerIdx].m_nIndex <= 0)
				break;
			Player[pLeave->m_nPlayerIdx].m_cTong.Leave(pLeave);
		}
		break;

	// �뿪����ж�
	// uParam : ����� TONG_APPLY_CHANGE_MASTER_COMMAND point
	// nParam : PlayerIndex
	case SGDI_TONG_CHANGE_MASTER_POWER:
		if (uParam)
		{
			nRet = 0;
			TONG_APPLY_CHANGE_MASTER_COMMAND	*pChange = (TONG_APPLY_CHANGE_MASTER_COMMAND*)uParam;
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;
			if (Player[nParam].m_nIndex <= 0)
				break;
			nRet = Player[nParam].m_cTong.CheckChangeMasterPower(pChange);
		}
		break;

	// �ܷ���ܴ�λ�ж�
	// uParam : ����� STONG_SERVER_TO_CORE_CHECK_GET_MASTER_POWER point
	case SGDI_TONG_GET_MASTER_POWER:
		if (uParam)
		{
			nRet = 0;
			STONG_SERVER_TO_CORE_CHECK_GET_MASTER_POWER	*pCheck = (STONG_SERVER_TO_CORE_CHECK_GET_MASTER_POWER*)uParam;
			if (pCheck->m_nPlayerIdx <= 0 || pCheck->m_nPlayerIdx >= MAX_PLAYER)
				break;
			if (Player[pCheck->m_nPlayerIdx].m_nIndex <= 0)
				break;
			nRet = Player[pCheck->m_nPlayerIdx].m_cTong.CheckGetMasterPower(pCheck);
		}
		break;

	// ��λ�������ݸı�
	// uParam : ����� STONG_SERVER_TO_CORE_CHANGE_AS point
	case SGDI_TONG_CHANGE_AS:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_CHANGE_AS	*pAs = (STONG_SERVER_TO_CORE_CHANGE_AS*)uParam;
			if (pAs->m_nPlayerIdx <= 0 || pAs->m_nPlayerIdx >= MAX_PLAYER)
				break;
			if (Player[pAs->m_nPlayerIdx].m_nIndex <= 0)
				break;
			Player[pAs->m_nPlayerIdx].m_cTong.ChangeAs(pAs);
		}
		break;

	// ��������
	// uParam : ����� STONG_SERVER_TO_CORE_CHANGE_MASTER point
	case SGDI_TONG_CHANGE_MASTER:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_CHANGE_MASTER	*pChange = (STONG_SERVER_TO_CORE_CHANGE_MASTER*)uParam;
			int nIdx;
			nIdx = PlayerSet.GetFirstPlayer();
			while (nIdx)
			{
				if (Player[nIdx].m_cTong.GetTongNameID() == pChange->m_dwTongNameID)
				{
					Player[nIdx].m_cTong.ChangeMaster(pChange->m_szName);
				}
				nIdx = PlayerSet.GetNextPlayer();
			}
		}
		break;

	// ��ð�����ַ���ת���ɵ� dword
	// nParam : PlayerIndex
	case SGDI_TONG_GET_TONG_NAMEID:
		{
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;
			if (Player[nParam].m_nIndex <= 0)
				break;
			nRet = Player[nParam].m_cTong.GetTongNameID();
		}
		break;

	// ��½ʱ���ð����Ϣ
	// uParam : ����� STONG_SERVER_TO_CORE_LOGIN point
	case SGDI_TONG_LOGIN:
		if (uParam)
		{
			
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;

			if (Player[nParam].m_nIndex <= 0)
				break;

			Player[nParam].m_cTong.LoadLogin(uParam);
		}
		break;
		
	// ֪ͨcore����ĳ��ҵİ����Ϣ
	// nParam : player index
	case SGDI_TONG_SEND_SELF_INFO:
		{
			if (nParam <= 0 || nParam >= MAX_PLAYER)
				break;
			if (Player[nParam].m_nIndex <= 0)
				break;
			Player[nParam].m_cTong.SendSelfInfo();
		}
		break;

	case SGDI_CHARACTER_SEX:
		{
			if (uParam <= 0 || uParam >= MAX_PLAYER)
				break;
			if (Player[uParam].m_nIndex <= 0)
				break;
			nRet = Npc[Player[uParam].m_nIndex].m_nSex;
		}
		break;

	case SGDI_TONG_CHANGE_TITLE_FEMALE:
		{
			if (uParam <= 0 || uParam >= MAX_PLAYER)
				break;
			if (Player[uParam].m_nIndex <= 0)
				break;

			TONG_APPLY_CHANGE_TITLE_FEMALE	*pChange = (TONG_APPLY_CHANGE_TITLE_FEMALE*)nParam;
            
			Player[uParam].m_cTong.ChangeTitleFeMale(pChange->m_dwTongNameID,pChange->m_szTitle);
			
		}
		break;

	case SGDI_TONG_CHANGE_TITLE_MALE:
		{
			if (uParam <= 0 || uParam >= MAX_PLAYER)
				break;
			if (Player[uParam].m_nIndex <= 0)
				break;

			TONG_APPLY_CHANGE_TITLE_MALE	*pChange = (TONG_APPLY_CHANGE_TITLE_MALE*)nParam;
            
			Player[uParam].m_cTong.ChangeTitleMale(pChange->m_dwTongNameID,pChange->m_szTitle);
			
		}
		break;
	case SGDI_TONG_CHANGE_TITLE:
		{
			if (uParam <= 0 || uParam >= MAX_PLAYER)
				break;
			if (Player[uParam].m_nIndex <= 0)
				break;

			TONG_APPLY_CHANGE_TITLE	*pChange = (TONG_APPLY_CHANGE_TITLE*)nParam;
            
			Player[uParam].m_cTong.ChangeTitle(pChange->m_dwTongNameID,pChange->m_szName,pChange->m_szTitle);
			
		}
		break;


	case SGDI_TONG_DEPOSIT_MONEY:
		{
			if (uParam <= 0 || uParam >= MAX_PLAYER)
				break;
			if (Player[uParam].m_nIndex <= 0)
				break;

			TONG_APPLY_DEPOSIT_MONEY	*pChange = (TONG_APPLY_DEPOSIT_MONEY*)nParam;
            
			Player[uParam].m_cTong.DepositMoney(pChange->m_dwTongNameID,pChange->m_nMoney);
			
		}
		break;





	case SGDI_TONG_TAKE_MONEY:
		{
			if (uParam <= 0 || uParam >= MAX_PLAYER)
				break;
			if (Player[uParam].m_nIndex <= 0)
				break;

			TONG_APPLY_TAKE_MONEY	*pChange = (TONG_APPLY_TAKE_MONEY*)nParam;
            
			Player[uParam].m_cTong.TakeMoney(pChange->m_dwTongNameID,pChange->m_nMoney);
			
		}
		break;



	case SGDI_CHARACTER_CAMP:
		if (uParam)
		{
			if (uParam >= MAX_PLAYER)
			{
				nRet = 0;
				break;
			}
			nRet = PlayerSet.GetPlayerCamp(uParam);
		}
		break;


   

	default:
		break;
	}
	return nRet;
}

//--------------------------------------------------------------------------
//	���ܣ�����Ϸ���Ͳ���
//	������unsigned int uDataId --> Core�ⲿ�ͻ���core�Ĳ����������������
//							��ֵΪ÷������GAMEOPERATION_INDEX��ȡֵ֮һ��
//		  unsigned int uParam  --> ����uOperId��ȡֵ�������
//		  int nParam --> ����uOperId��ȡֵ�������
//	���أ�����ɹ����Ͳ������󣬺������ط�0ֵ�����򷵻�0ֵ��
//--------------------------------------------------------------------------
int	CoreServerShell::OperationRequest(unsigned int uOper, unsigned int uParam, int nParam)
{
	int nRet = 1;
	switch(uOper)
	{		
	case SSOI_BROADCASTING:
		nRet = PlayerSet.Broadcasting((char*)uParam, nParam);
		break;
	case SSOI_LAUNCH:	//��������
		nRet = OnLunch((LPVOID)uParam);
		break;
	case SSOI_SHUTDOWN:	//�رշ���
		nRet = OnShutdown();
		break;
	case SSOI_RELOAD_WELCOME_MSG:
		PlayerSet.ReloadWelcomeMsg();
		break;

	// relay ��ᴴ���ɹ���֪ͨ core ������Ӧ�Ĵ���
	case SSOI_TONG_CREATE:
		{
			STONG_SERVER_TO_CORE_CREATE_SUCCESS	*pCreate = (STONG_SERVER_TO_CORE_CREATE_SUCCESS*)uParam;
			if (pCreate->m_nPlayerIdx <= 0 || pCreate->m_nPlayerIdx >= MAX_PLAYER)
			{
				nRet = 0;
				break;
			}
			if (Player[pCreate->m_nPlayerIdx].m_nIndex)
			{
				DWORD	dwID = g_FileName2Id(Npc[Player[pCreate->m_nPlayerIdx].m_nIndex].Name);
				if (dwID != pCreate->m_dwPlayerNameID)
				{
					nRet = 0;
					break;
				}
			}
			else
			{
				nRet = 0;
				break;
			}
			
		}
		break;

	case SSOI_TONG_REFUSE_ADD:
		if (uParam)
		{
			STONG_SERVER_TO_CORE_REFUSE_ADD	*pRefuse = (STONG_SERVER_TO_CORE_REFUSE_ADD*)uParam;
			if (pRefuse->m_nSelfIdx > 0 && pRefuse->m_nSelfIdx <= MAX_PLAYER)
			{
				Player[pRefuse->m_nSelfIdx].m_cTong.SendRefuseMessage(pRefuse->m_nTargetIdx, pRefuse->m_dwNameID);
			}
		}
		break;

	case SSOI_TONG_ADD:
		if (uParam)
		{
			nRet = 0;
			STONG_SERVER_TO_CORE_ADD_SUCCESS	*pAdd = (STONG_SERVER_TO_CORE_ADD_SUCCESS*)uParam;
			if (pAdd->m_nPlayerIdx <= 0 || pAdd->m_nPlayerIdx >= MAX_PLAYER)
				break;
			if (Player[pAdd->m_nPlayerIdx].m_nIndex <= 0)
				break;
			if (g_FileName2Id(Npc[Player[pAdd->m_nPlayerIdx].m_nIndex].Name) != pAdd->m_dwPlayerNameID)
				break;
			Player[pAdd->m_nPlayerIdx].m_cTong.AddTong(
				pAdd->m_nCamp,
				pAdd->m_szTongName,
				pAdd->m_szMasterName,
				pAdd->m_szTitleName);
		}
		break;

	default:
		nRet = 0;
		break;
	}	
	return nRet;
}

int CoreServerShell::OnLunch(LPVOID pServer)
{
	g_SetServer(pServer);

//	g_SetFilePath("\\script");

	try
	{

	KLuaScript * pStartScript =(KLuaScript*) g_GetScript("\\script\\admin\\khoidong.lua");
	int i = 0;
	
	if (!pStartScript)
		g_DebugLog("Load ServerScript failed!");
	else
	{

		

		int nTopIndex = 0;
			
		pStartScript->SafeCallBegin(&nTopIndex);	
		pStartScript->CallFunction("main",0,"");
		pStartScript->SafeCallEnd(nTopIndex);

		
	}


	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit khoi dong \\script\\admin\\khoidong.lua!!!!!");
	}


    printf("Spcrit khoi dong chay xong, so luong Npc da Add: %d\n", NpcSet.m_nNumberCountNpcSet);


	PlayerSet.ReloadWelcomeMsg();

	return true;
}

int CoreServerShell::OnShutdown()
{

/*
	try
	{


KLuaScript * pStartScript1 =(KLuaScript*) g_GetScript("\\script\\kytrancac.lua");

	
	
	if (!pStartScript1)
		printf("Xay ra loi Load Spcrit Save \\script\\kytrancac.lua !!!!!");
	else
	{	
		
		int nTopIndex1 = 0;
		pStartScript1->SafeCallBegin(&nTopIndex1);
		pStartScript1->CallFunction("save",0,"");
		pStartScript1->SafeCallEnd(nTopIndex1);
		
	}



	
	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save \\script\\kytrancac.lua !!!!!");
	}

*/
/*
	try
	{



KLuaScript * pStartScript2 =(KLuaScript*) g_GetScript("\\script\\item\\questkey\\15.lua");
	
	
	if (!pStartScript2)
		printf("Xay ra loi Load Spcrit Save \\script\\item\\questkey\\15.lua !!!!!");
	else
	{	
	
		int nTopIndex2 = 0;
		pStartScript2->SafeCallBegin(&nTopIndex2);
		pStartScript2->CallFunction("save",0,"");
		pStartScript2->SafeCallEnd(nTopIndex2);
		
	}



	}


	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save \\script\\item\\questkey\\15.lua !!!!!");
	}

*/

	try
	{
	
    KLuaScript * pStartScript3 =(KLuaScript*) g_GetScript("\\script\\admin\\banghoi\\banghoi.lua");
	
	if (!pStartScript3)
	   printf("Xay ra loi Load Spcrit Save \\script\\admin\\banghoi\\banghoi.lua !!!!!");
	else
	{	
		
		int nTopIndex3 = 0;
		pStartScript3->SafeCallBegin(&nTopIndex3);
		pStartScript3->CallFunction("save",0,"");
		pStartScript3->SafeCallEnd(nTopIndex3);
		
	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save \\script\\admin\\banghoi\\banghoi.lua !!!!!");
	}




	try
	{
	
    KLuaScript * pStartScript4 =(KLuaScript*) g_GetScript("\\script\\congthanh\\npccongthanh.lua");
	
	if (!pStartScript4)
	   printf("Xay ra loi Load Spcrit Save \\script\\congthanh\\npccongthanh.lua !!!!!");
	else
	{	
		
		int nTopIndex4 = 0;
		pStartScript4->SafeCallBegin(&nTopIndex4);
		pStartScript4->CallFunction("save",0,"");
		pStartScript4->SafeCallEnd(nTopIndex4);
		
	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save \\script\\congthanh\\npccongthanh.lua !!!!!");
	}














	try
	{
	
    KLuaScript * pStartScript5 =(KLuaScript*) g_GetScript("\\script\\liendau\\sugiald.lua");
	
	if (!pStartScript5)
	   printf("Xay ra loi Load Spcrit Save \\script\\liendau\\sugiald.lua !!!!!");
	else
	{	
		
		int nTopIndex5 = 0;
		pStartScript5->SafeCallBegin(&nTopIndex5);
		pStartScript5->CallFunction("save",0,"");
		pStartScript5->SafeCallEnd(nTopIndex5);
		
	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save \\script\\liendau\\sugiald.lua !!!!!");
	}

  













	return true;
}


//�ճ����core���Ҫ���������򷵻�0�����򷵻ط�0ֵ
int CoreServerShell::Breathe()
{

if (g_SubWorldSet.GetGameTime()% (60*60*18) == 0)
{






printf("Save timer Spcrit !\n");

/*
	try
	{


	KLuaScript * pStartScript1 =(KLuaScript*) g_GetScript("\\script\\kytrancac.lua");
	if (!pStartScript1)
		printf("Xay ra loi Load Spcrit Save Timer \\script\\kytrancac.lua !!!!!");
	else
	{
		
		

		int nTopIndex1 = 0;
			
		pStartScript1->SafeCallBegin(&nTopIndex1);
		pStartScript1->CallFunction("savetimer",0,"");
		pStartScript1->SafeCallEnd(nTopIndex1);

	

	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save Timer \\script\\kytrancac.lua !!!!!");
	}


*/
/*
	try
	{

    KLuaScript * pStartScript2 =(KLuaScript*) g_GetScript("\\script\\item\\questkey\\15.lua");	
	
	if (!pStartScript2)
		printf("Xay ra loi Load Spcrit Save Timer \\script\\item\\questkey\\15.lua !!!!!");
	else
	{	

		
		int nTopIndex2 = 0;		
		pStartScript2->SafeCallBegin(&nTopIndex2);
		pStartScript2->CallFunction("savetimer",0,"");
		pStartScript2->SafeCallEnd(nTopIndex2);
		
	}



	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save Timer \\script\\item\\questkey\\15.lua !!!!!");
	}


*/


	try
	{

	 KLuaScript * pStartScript3 =(KLuaScript*) g_GetScript("\\script\\admin\\banghoi\\banghoi.lua");	
	
	if (!pStartScript3)
		printf("Xay ra loi Load Spcrit Save Timer \\script\\admin\\banghoi\\banghoi.lua !!!!!");
	else
	{	
		
		int nTopIndex3 = 0;		
		pStartScript3->SafeCallBegin(&nTopIndex3);
		pStartScript3->CallFunction("savetimer",0,"");
		pStartScript3->SafeCallEnd(nTopIndex3);
	
	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save Timer \\script\\admin\\banghoi\\banghoi.lua !!!!!");
	}



	try
	{

	 KLuaScript * pStartScript4 =(KLuaScript*) g_GetScript("\\script\\congthanh\\npccongthanh.lua");	
	
	if (!pStartScript4)
		printf("Xay ra loi Load Spcrit Save Timer \\script\\congthanh\\npccongthanh.lua !!!!!");
	else
	{	
		
		int nTopIndex4 = 0;		
		pStartScript4->SafeCallBegin(&nTopIndex4);
		pStartScript4->CallFunction("savetimer",0,"");
		pStartScript4->SafeCallEnd(nTopIndex4);
	
	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save Timer \\script\\congthanh\\npccongthanh.lua !!!!!");
	}















	try
	{

	 KLuaScript * pStartScript5 =(KLuaScript*) g_GetScript("\\script\\liendau\\sugiald.lua");	
	
	if (!pStartScript5)
		printf("Xay ra loi Load Spcrit Save Timer \\script\\liendau\\sugiald.lua !!!!!");
	else
	{	
		
		int nTopIndex5 = 0;		
		pStartScript5->SafeCallBegin(&nTopIndex5);
		pStartScript5->CallFunction("savetimer",0,"");
		pStartScript5->SafeCallEnd(nTopIndex5);
	
	}

	}

	catch(...)
	{
		printf("Xay ra loi chay Spcrit Save Timer \\script\\liendau\\sugiald.lua !!!!!");
	}











printf("Save timer Spcrit Finish !\n");	







}		
	
	g_SubWorldSet.MessageLoop();
	g_SubWorldSet.MainLoop();
	return true;
}








bool CoreServerShell::CheckProtocolSize(const char* pChar, int nSize)
{
	WORD wCheckSize;
	BYTE nProtocol = (BYTE)pChar[0];

	if (nProtocol >= c2s_end || nProtocol <= c2s_gameserverbegin)
	{
		g_DebugLog("[error]NetServer:Invalid Protocol!");
		return false;
	}

	if (g_nProtocolSize[nProtocol - c2s_gameserverbegin - 1] == -1)
	{
		wCheckSize = *(WORD*)&pChar[1] + PROTOCOL_MSG_SIZE;
	}
	else
	{
		wCheckSize = g_nProtocolSize[nProtocol - c2s_gameserverbegin - 1];
	}
	if (wCheckSize != nSize)
	{
		g_DebugLog("[error]�������Э���С��ƥ��");
#ifndef _WIN32
		printf("[error]�������Э���С��ƥ��<%d>, should %d, but %d\n", nProtocol, wCheckSize, nSize);
#endif
		return false;
	}
	return true;
}


int CoreServerShell::AttachPlayer(const unsigned long lnID, GUID* pGuid)
{
	return PlayerSet.AttachPlayer(lnID, pGuid);
}

void* CoreServerShell::SavePlayerDataAtOnce(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
	{
		return NULL;
	}

	if (Player[nIndex].Save())
	{
		Player[nIndex].m_uMustSave = SAVE_REQUEST;
		return &Player[nIndex].m_SaveBuffer;
	}
	else
	{
		return NULL;
	}
}
// UY THAC
//void CoreServerShell::SetAutoTroLai(int nIndex,BOOL bCheck)
//{
 	//if (nIndex <= 0 || nIndex >= MAX_PLAYER)
 	//{
 	//	return;
 	//}	
//	Player[nIndex].m_AutoTroLai = bCheck;
//}

void CoreServerShell::SetCharacterLiXian(int nIndex,int i)
{
 	//if (nIndex <= 0 || nIndex >= MAX_PLAYER)
 	//{
 	//	return;
 	//}	
	Player[nIndex].m_nLiXian = i;
}


int CoreServerShell::IsCharacterLiXian(int nIndex)
{
 	//if (nIndex <= 0 || nIndex >= MAX_PLAYER)
 	//{
 	//	return FALSE;
 	//}	
	return Player[nIndex].m_nLiXian;
}
int CoreServerShell::IsCheckLiXian(int nIndex)
{
 	//if (nIndex <= 0 || nIndex >= MAX_PLAYER)
 	//{
 	//	return FALSE;
 	//}	
	return Player[nIndex].m_nLiXian2;
}

// END
bool CoreServerShell::IsCharacterQuiting(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
	{
		return FALSE;
	}	
	return Player[nIndex].IsWaitingRemove();
}

bool CoreServerShell::IsPlayerLoginTimeOut(int nIndex)
{
	return Player[nIndex].IsLoginTimeOut();
}

void CoreServerShell::RemovePlayerLoginTimeOut(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;
	if (Player[nIndex].IsLoginTimeOut())
	{
		PlayerSet.RemoveLoginTimeOut(nIndex);
	}
}


int CoreServerShell::AddTempTaskValue(int nIndex, const char* pData)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return 0;

	return Player[nIndex].AddTempTaskValue((void *)pData);
}

void CoreServerShell::GetPlayerIndexByGuid(GUID* pGuid, int* pnIndex, int* plnID)
{
	*pnIndex = PlayerSet.GetPlayerIndexByGuid(pGuid);
	if (*pnIndex)
	{
		*plnID = Player[*pnIndex].m_nNetConnectIdx;
	}
	else
	{
		*plnID = -1;
	}

	if (*plnID == -1)
	{
		*pnIndex = 0;
	}
}

void* CoreServerShell::PreparePlayerForExchange(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return NULL;
	PlayerSet.PrepareExchange(nIndex);
	return &Player[nIndex].m_SaveBuffer;
}

bool CoreServerShell::IsPlayerExchangingServer(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return false;

	return Player[nIndex].IsExchangingServer();
}

void CoreServerShell::RemovePlayerForExchange(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;

	PlayerSet.RemoveExchanging(nIndex);
}

void CoreServerShell::GetGuid(int nIndex, void* pGuid)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;
	memcpy(pGuid, &Player[nIndex].m_Guid, sizeof(GUID));
}

DWORD CoreServerShell::GetExchangeMap(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return -1;

	return Player[nIndex].m_sExchangePos.m_dwMapID;
}

void CoreServerShell::RecoverPlayerExchange(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;

	Player[nIndex].m_bExchangeServer = FALSE;
	if (Player[nIndex].m_nIndex > 0)
	{
		KNpc* pNpc = &Npc[Player[nIndex].m_nIndex];
		pNpc->m_bExchangeServer = FALSE;
		pNpc->m_FightMode = pNpc->m_OldFightMode;
	}
	Player[nIndex].Earn(Player[nIndex].m_nPrePayMoney);
	Player[nIndex].m_nPrePayMoney = 0;
}

void CoreServerShell::SetSaveStatus(int nIndex, UINT uStatus)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;

	Player[nIndex].m_uMustSave = uStatus;
}

UINT CoreServerShell::GetSaveStatus(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return SAVE_IDLE;

	return Player[nIndex].m_uMustSave;
}


void CoreServerShell::PreparePlayerForLoginFailed(int nIndex)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return;

	PlayerSet.PrepareLoginFailed(nIndex);
}
//BOOL CoreServerShell::ValidPingTime(int nIndex)
//{
//	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
//		return FALSE;
//
//	if (Player[nIndex].m_uLastPingTime == -1)
//		return TRUE;
//	
//#define	MAX_PING_TIME	(60 * 20)	//	1min
//	if (g_SubWorldSet.GetGameTime() - Player[nIndex].m_uLastPingTime > MAX_PING_TIME)
//	{
//		return FALSE;
//	}
//	return TRUE;
//}

BOOL CoreServerShell::GroupChat(IClient* pClient, DWORD FromIP, unsigned long FromRelayID, DWORD channid, BYTE tgtcls, DWORD tgtid, const void* pData, size_t size)
{
	switch(tgtcls)
	{

	case tgtcls_team:
		{{
		if (tgtid < 0 || tgtid >= MAX_TEAM)
			return FALSE;

		size_t pckgsize = sizeof(tagExtendProtoHeader) + size;
#ifdef WIN32
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)_alloca(pckgsize);
#else
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)(new char[pckgsize]);
#endif
		pExHeader->ProtocolType = s2c_extendchat;
		pExHeader->wLength = pckgsize - 1;
		memcpy(pExHeader + 1, pData, size);

		int nTargetIdx;
		// ���ӳ���
		nTargetIdx = g_Team[tgtid].m_nCaptain;
//		if (FromRelayID != Player[nTargetIdx].m_nNetConnectIdx)
			g_pServer->SendData(Player[nTargetIdx].m_nNetConnectIdx, pData, size);
		// ����Ա��
		for (int i = 0; i <	MAX_TEAM_MEMBER; i++)
		{
			nTargetIdx = g_Team[tgtid].m_nMember[i];
			if (nTargetIdx < 0)
				continue;

//			if (FromRelayID != Player[nTargetIdx].m_nNetConnectIdx)
				g_pServer->PackDataToClient(Player[nTargetIdx].m_nNetConnectIdx, pExHeader, pckgsize);
		}
#ifndef WIN32
		delete ((char*)pExHeader);
#endif
		}}
		break;
	case tgtcls_kim:
		{{
		size_t pckgsize = sizeof(tagExtendProtoHeader) + size;
#ifdef WIN32
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)_alloca(pckgsize);
#else
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)(new char[pckgsize]);
#endif
		pExHeader->ProtocolType = s2c_extendchat;
		pExHeader->wLength = pckgsize - 1;
		memcpy(pExHeader + 1, pData, size);

		int nTargetIdx;
		nTargetIdx = PlayerSet.GetFirstPlayer();
		while (nTargetIdx)
		{
			if (Player[nTargetIdx].m_cTask.GetSaveVal(TASK_CHAT_TONGKIM) == tgtid)
				g_pServer->PackDataToClient(Player[nTargetIdx].m_nNetConnectIdx, pExHeader, pckgsize);
			nTargetIdx = PlayerSet.GetNextPlayer();
		}
#ifndef WIN32
		delete ((char*)pExHeader);
#endif
		}}
		break;
	case tgtcls_fac:
		{{
		size_t pckgsize = sizeof(tagExtendProtoHeader) + size;
#ifdef WIN32
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)_alloca(pckgsize);
#else
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)(new char[pckgsize]);
#endif
		pExHeader->ProtocolType = s2c_extendchat;
		pExHeader->wLength = pckgsize - 1;
		memcpy(pExHeader + 1, pData, size);

		int nTargetIdx;
		nTargetIdx = PlayerSet.GetFirstPlayer();
		while (nTargetIdx)
		{
			if (Player[nTargetIdx].m_cFaction.m_nCurFaction == tgtid
)//				&& FromRelayID != Player[nTargetIdx].m_nNetConnectIdx)
				g_pServer->PackDataToClient(Player[nTargetIdx].m_nNetConnectIdx, pExHeader, pckgsize);

			nTargetIdx = PlayerSet.GetNextPlayer();
		}
#ifndef WIN32
		delete ((char*)pExHeader);
#endif
		}}
		break;

	case tgtcls_tong:
		{{
		size_t pckgsize = sizeof(tagExtendProtoHeader) + size;
#ifdef WIN32
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)_alloca(pckgsize);
#else
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)(new char[pckgsize]);
#endif
		pExHeader->ProtocolType = s2c_extendchat;
		pExHeader->wLength = pckgsize - 1;
		memcpy(pExHeader + 1, pData, size);

		int nTargetIdx;
		nTargetIdx = PlayerSet.GetFirstPlayer();
		while (nTargetIdx)
		{
			if (Player[nTargetIdx].m_cTong.GetTongNameID() == tgtid
)//				&& FromRelayID != Player[nTargetIdx].m_nNetConnectIdx)
				g_pServer->PackDataToClient(Player[nTargetIdx].m_nNetConnectIdx, pExHeader, pckgsize);

			nTargetIdx = PlayerSet.GetNextPlayer();
		}
#ifndef WIN32
		delete ((char*)pExHeader);
#endif
		}}
		break;

	case tgtcls_scrn:
		{{

//		int nMaxRelayPlayer = (1024 - 32 - sizeof(CHAT_GROUPMAN) - size) / sizeof(WORD);
//		if (nMaxRelayPlayer <= 0)
//			return FALSE;


		int idxNPC = Player[tgtid].m_nIndex;
		int idxSubWorld = Npc[idxNPC].m_SubWorldIndex;
		int idxRegion = Npc[idxNPC].m_RegionIndex;
//		_ASSERT(idxSubWorld >= 0 && idxRegion >= 0);
		int nOX = Npc[idxNPC].m_MapX;
		int nOY = Npc[idxNPC].m_MapY;
		int nTX = 0;
		int nTY = 0;
		if (idxSubWorld < 0 || idxRegion < 0)
			return FALSE;


//		size_t basesize = sizeof(CHAT_GROUPMAN) + size;
//		BYTE buffer[1024];
//
//		CHAT_GROUPMAN* pCgc = (CHAT_GROUPMAN*)buffer;
//		pCgc->ProtocolType = chat_groupman;
//		pCgc->wChatLength = size;
//		pCgc->byHasIdentify = false;
//
//		void* pExPckg = pCgc + 1;
//		memcpy(pExPckg, pData, size);
//
//		WORD* pPlayers = (WORD*)((BYTE*)pExPckg + size);
//
//
//		pCgc->wPlayerCount = 0;


		size_t pckgsize = sizeof(tagExtendProtoHeader) + size;
#ifdef WIN32
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)_alloca(pckgsize);
#else
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)(new char[pckgsize]);
#endif
		pExHeader->ProtocolType = s2c_extendchat;
		pExHeader->wLength = pckgsize - 1;
		memcpy(pExHeader + 1, pData, size);

#define	MAX_SYNC_RANGE	23
		static POINT POff[9] = 
		{
			{0, 0},
			{0, 32},
			{-16, 32},
			{-16, 0},
			{-16, -32},
			{0, -32},
			{16, -32},
			{16, 0},
			{16, 32},
		};

		KRegion* pRegionBase = &SubWorld[idxSubWorld].m_Region[idxRegion];

		for (int i = -1; i < 8; i++)
		{
			KRegion* pRegion = NULL;
			if (i < 0)
				pRegion = pRegionBase;
			else
			{
				if (pRegionBase->m_nConnectRegion[i] < 0)
					continue;
				pRegion = &SubWorld[idxSubWorld].m_Region[pRegionBase->m_nConnectRegion[i]];
			}
			if (pRegion == NULL)
				continue;


			KIndexNode *pNode = (KIndexNode *)pRegion->m_PlayerList.GetHead();
			while(pNode)
			{
//				_ASSERT(pNode->m_nIndex > 0 && pNode->m_nIndex < MAX_PLAYER);

				//if (FromRelayID != Player[pNode->m_nIndex].m_nNetConnectIdx)
				{
					int nTargetNpc = Player[pNode->m_nIndex].m_nIndex;
					if (nTargetNpc > 0)
					{
						nTX = Npc[nTargetNpc].m_MapX + POff[i + 1].x;
						nTY = Npc[nTargetNpc].m_MapY + POff[i + 1].y;
						
						if ((nTX - nOX) * (nTX - nOX) + (nTY - nOY) * (nTY - nOY) < MAX_SYNC_RANGE * MAX_SYNC_RANGE)
							g_pServer->PackDataToClient(Player[pNode->m_nIndex].m_nNetConnectIdx, pExHeader, pckgsize);
					}


//					pPlayers[pCgc->wPlayerCount] = (WORD)Player[pNode->m_nIndex].m_nNetConnectIdx;
//					++ pCgc->wPlayerCount;
//
//					if (pCgc->wPlayerCount >= nMaxRelayPlayer)
//					{
//						size_t pckgsize = basesize + sizeof(WORD) * pCgc->wPlayerCount;
//						pCgc->wSize = pckgsize - 1;
//						
//						pClient->SendPackToServer(pCgc, pckgsize);
//
//						pCgc->wPlayerCount = 0;
//					}
				}

				pNode = (KIndexNode *)pNode->GetNext();
			}
		}

//		if (pCgc->wPlayerCount > 0)
//		{
//			size_t pckgsize = basesize + sizeof(WORD) * pCgc->wPlayerCount;
//			pCgc->wSize = pckgsize - 1;
//
//			pClient->SendPackToServer(pCgc, pckgsize);
//		}

#ifndef WIN32
		delete (char*)pExHeader;
#endif
		}}
		break;


	case tgtcls_bc:
		{{
		size_t pckgsize = sizeof(tagExtendProtoHeader) + size;
#ifdef WIN32
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)_alloca(pckgsize);
#else
		tagExtendProtoHeader* pExHeader = (tagExtendProtoHeader*)(new char[pckgsize]);
#endif
		pExHeader->ProtocolType = s2c_extendchat;
		pExHeader->wLength = pckgsize - 1;
		memcpy(pExHeader + 1, pData, size);

		int nTargetIdx;
		nTargetIdx = PlayerSet.GetFirstPlayer();
		while (nTargetIdx)
		{
			g_pServer->PackDataToClient(Player[nTargetIdx].m_nNetConnectIdx, pExHeader, pckgsize);

			nTargetIdx = PlayerSet.GetNextPlayer();
		}
#ifndef WIN32
		delete ((char*)pExHeader);
#endif
		}}
		break;


	default:
		break;
	}
	return TRUE;
}

void CoreServerShell::SetLadder(void* pData, size_t uSize)
{
	Ladder.Init(pData, uSize);
}




BOOL CoreServerShell::CheckCastChat(int nIndex, int nType)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return FALSE;

	int nNpcIdx = Player[nIndex].m_nIndex;
	if (nNpcIdx <= 0)
		return FALSE;

	if (Player[nIndex].m_cChat.m_nTimer < 20)
	{
		
		return FALSE;
	}

	Player[nIndex].m_cChat.m_nTimer = 0;
	    return TRUE;


}

BOOL CoreServerShell::PayForSpeech(int nIndex, int nType)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return FALSE;

	int	nMoney = 0;
	int nNpcIdx = Player[nIndex].m_nIndex;
	if (nNpcIdx <= 0)
		return FALSE;
	if (Player[nIndex].m_nForbiddenFlag & KPlayer::FF_CHAT)	//������
		return FALSE;
	int nLevel = Npc[nNpcIdx].m_Level;
	int nMaxMana = Npc[nNpcIdx].m_CurrentManaMax;
	switch (nType)
	{
	case 0:		//���
		return TRUE;
		break;
	case 1:		//10Ԫÿ��
		{
			nMoney = 10;
			return Player[nIndex].Pay(nMoney);
		}
		break;
	case 2:		//2: <10Lv ? ����˵ : MaxMana/2/��
		{
			if (nLevel < 130)
				return FALSE;
			return Npc[nNpcIdx].Cost(attrib_mana, nMaxMana / 2);
		}
		break;
	case 3:		//3: MaxMana/10/��
		{
			return Npc[nNpcIdx].Cost(attrib_mana, nMaxMana / 10);
		}
		break;
	case 4:		//4: <20Lv ? ����˵ : MaxMana*4/5/��
		{
			if (nLevel < 20)
				return FALSE;
			return Npc[nNpcIdx].Cost(attrib_mana, nMaxMana * 4 / 5);
		}
		break;
	default:
		return FALSE;	//����ʶ����𲻷���
	}
}



BOOL CoreServerShell::PayForSpeech2(int nIndex, int nType, int nChanelId)
{
	if (nIndex <= 0 || nIndex >= MAX_PLAYER)
		return FALSE;



	int	nMoney = 0;
	int nNpcIdx = Player[nIndex].m_nIndex;
	if (nNpcIdx <= 0)
		return FALSE;
	if (Player[nIndex].m_nForbiddenFlag & KPlayer::FF_CHAT)	//������
		return FALSE;
	int nLevel = Npc[nNpcIdx].m_Level;
	int nMaxMana = Npc[nNpcIdx].m_CurrentManaMax;
	// channell = 1 la The Gioi, = 6 la Phu Can
	printf("\nTest %d [%d] - [%s] - [%s] \n",nChanelId, nLevel, Player[nIndex].m_AccoutName, Player[nIndex].m_PlayerName);
	if (nChanelId == 4)
	{
		printf("\nTest %d [%d] - [%s] - [%s] \n",nChanelId, nLevel, Player[nIndex].m_AccoutName, Player[nIndex].m_PlayerName);
	}
	if ((nChanelId == 15) && nLevel < 130)
	{
		KPlayerChat::SendSystemInfo(1,nIndex, MESSAGE_SYSTEM_ANNOUCE_HEAD, "��ng c�p nh� h�n 110, kh�ng th� chat !", strlen("��ng c�p nh� h�n 50, kh�ng th� chat !") );	
		return FALSE;
	}
	
	if ((nChanelId == 1 || nChanelId == 7) && nLevel < 130)
	{
		KPlayerChat::SendSystemInfo(1,nIndex, MESSAGE_SYSTEM_ANNOUCE_HEAD, "��ng c�p nh� h�n 110, kh�ng th� chat !", strlen("��ng c�p nh� h�n 50, kh�ng th� chat !") );	
		return FALSE;
	}
	switch (nType)
	{
	case 0:		//���
		return TRUE;
		break;
	case 1:		//10Ԫÿ��
		{
			nMoney = 10;
			return Player[nIndex].Pay(nMoney);
		}
		break;
	case 2:		//2: <10Lv ? ����˵ : MaxMana/2/��
		{
			if (nLevel < 130)
				return FALSE;
			return Npc[nNpcIdx].Cost(attrib_mana, nMaxMana);
		}
		break;
	case 3:		//3: MaxMana/10/��
		{
			return Npc[nNpcIdx].Cost(attrib_mana, nMaxMana / 10);
		}
		break;
	case 4:		//4: <20Lv ? ����˵ : MaxMana*4/5/��
		{
			if (nLevel < 20)
				return FALSE;
			return Npc[nNpcIdx].Cost(attrib_mana, nMaxMana * 4 / 5);
		}
		break;
	default:
		return FALSE;	//����ʶ����𲻷���
	}
}