/*******************************************************************************
// FileName			:	KMissleMagicAttribsData.cpp
// FileAuthor		:	RomanDou
// FileCreateDate	:	2002-10-8 2:03:26
// FileDescription	:	
// Revision Count	:	
*******************************************************************************/

