#ifndef TASKDEF_H
#define TASKDEF_H

#include "KEngine.h"
#include "KTabFile.h"
#ifdef _SERVER
extern KTabFile g_MissionTabFile;
#endif
#endif
