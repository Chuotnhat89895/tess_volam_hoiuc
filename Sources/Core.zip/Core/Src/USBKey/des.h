#ifndef __DES_H 
#define __DES_H  

	int Des_Go(char *pIn,char *pOut,long cbData,char pKey[8],int fEncrypt);

#endif 
