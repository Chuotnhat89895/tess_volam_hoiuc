// cLittleMap.h: interface for the cLittleMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLITTLEMAP_H__09658E99_FB69_4E59_B94E_96F173C83AE9__INCLUDED_)
#define AFX_CLITTLEMAP_H__09658E99_FB69_4E59_B94E_96F173C83AE9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class cLittleMap  
{
public:
	cLittleMap();
	virtual ~cLittleMap();

};

#endif // !defined(AFX_CLITTLEMAP_H__09658E99_FB69_4E59_B94E_96F173C83AE9__INCLUDED_)
